// Back to Top
$('.backtotop').click(function() {
    $('body,html').animate({
        scrollTop: 0
    }, 600);
});
